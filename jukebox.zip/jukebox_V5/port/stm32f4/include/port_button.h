/**
 * @file port_button.h
 * @brief Header for port_button.c file.
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 02/2024
 */

#ifndef PORT_BUTTON_H_
#define PORT_BUTTON_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdint.h>
#include <stdbool.h>

/* HW dependent includes */
#include "port_system.h"

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define BUTTON_0_ID 0                 /*!< Button identifier number*/
#define BUTTON_0_GPIO GPIOC           /*!< GPIO to which the button is connected*/
#define BUTTON_0_PIN 13               /*!< Button pin*/
#define BUTTON_0_DEBOUNCE_TIME_MS 150 /*!< Anti-bounce time in ms*/

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Button HW dependencies
 *
 */
typedef struct
{
    GPIO_TypeDef *p_port; /*!< button GPIO */
    uint8_t pin;          /*!< button pin */
    bool flag_pressed;    /*!< flag that indicates if the button has been pressed */
} port_button_hw_t;

/* Global variables */
/**
 * @brief Array of button HW characteristics
 *
 */
extern port_button_hw_t buttons_arr[];

/* Function prototypes and explanation -------------------------------------------------*/
/**
 * @brief Return the count of the system tick in milliseconds.
 *
 * @return uint32_t tick count
 */
uint32_t port_button_get_tick();

/**
 * @brief Configure the specifications of a button.
 *
 * @param button_id index used to select the element of the buttons_arr[]
 */
void port_button_init(uint32_t button_id);

/**
 * @brief Return the status of the button
 *
 * @param button_id index used to select the element of the buttons_arr[]
 *
 * @return boolean: true (button pressed) false (button not pressed)
 */
bool port_button_is_pressed(uint32_t button_id);

#endif