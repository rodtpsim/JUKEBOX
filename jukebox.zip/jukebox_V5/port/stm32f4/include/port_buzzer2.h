/**
 * @file port_buzzer2.h
 * @brief Header for port_buzzer2.c file.
 * @remark This file is created in V5
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gomez Fernandez-Getino
 * @date 05/2024
 */

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include "port_system.h"

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define BUZZER_1_ID 1       /*!< Buzzer 2 ID */
#define BUZZER_1_GPIO GPIOB /*!< Buzzer 2 player GPIO port */
#define BUZZER_1_PIN 6      /*!< Buzzer 2 GPIO pin */
#define BUZZER_PWM_DC2 0.5  /*!< PWM duty cycle */
#define BUZZER_1_AF 2       /*!< Alternate function*/

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Buzzer HW dependencies
 *
 */
typedef struct
{
    GPIO_TypeDef *p_port2; /*!< GPIO where the buzzer 2 player is connected */
    uint8_t pin2;          /*!< Pin where the buzzer 2 player is connected */
    uint8_t alt_func2;     /*!< Alternate function value for PWM */
    bool note_end2;        /*!< Flag to indicate that the note has ended */
} port_buzzer_hw_t2;

/* Global variables */
/**
 * @brief Array of buzzer HW characteristics
 */
extern port_buzzer_hw_t2 buzzers_arr2[];

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief Configures the hardware of the given buzzer player
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 */
void port_buzzer_init2(uint32_t buzzer_id);

/**
 * @brief Set the duration of the timer that contorls the duration of the note
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 * @param duration_ms duration in ms of the note
 */
void port_buzzer_set_note_duration2(uint32_t buzzer_id, uint32_t duration_ms);

/**
 * @brief Set the PWM frequency of the timer that contorls the frequency of the note
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 * @param frequency_hz frequency in hz of the note
 */
void port_buzzer_set_note_frequency2(uint32_t buzzer_id, double frequency_hz);

/**
 * @brief Get the status of the note_end flag
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 *
 * @return bool: true or false
 */
bool port_buzzer_get_note_timeout2(uint32_t buzzer_id);

/**
 * @brief Disable the PWM output and the timer that control the duration and the frequency of the note.
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 */
void port_buzzer_stop2(uint32_t buzzer_id);
