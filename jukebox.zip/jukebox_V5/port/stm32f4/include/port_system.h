/**
 * @file port_system.h
 * @brief Header for port_system.c file.
 * @author Sistemas Digitales II
 * @date 2024-01-01
 */

#ifndef PORT_SYSTEM_H_
#define PORT_SYSTEM_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

/* HW dependent includes */
#include "stm32f4xx.h"

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define BIT_POS_TO_MASK(x) (0x01 << (x))                                                                /*!< Convert the index of a bit into a mask by left shifting */
#define BASE_MASK_TO_POS(m, p) ((m) << (p))                                                             /*!< Move a mask defined in the LSBs to upper positions by shifting left p bits */
#define GET_PIN_IRQN(pin) (pin >= 10 ? EXTI15_10_IRQn : (pin >= 5 ? EXTI9_5_IRQn : (EXTI0_IRQn + pin))) /*!< Compute the IRQ number associated to a GPIO pin */

/* Microcontroller STM32F446RE */
/* Timer configuration */
#define RCC_HSI_CALIBRATION_DEFAULT 0x10U            /*!< Default HSI calibration trimming value */
#define TICK_FREQ_1KHZ 1U                            /*!< Freqency in kHz of the System tick */
#define NVIC_PRIORITY_GROUP_0 ((uint32_t)0x00000007) /*!< 0 bit  for pre-emption priority, \
                                                         4 bits for subpriority */
#define NVIC_PRIORITY_GROUP_4 ((uint32_t)0x00000003) /*!< 4 bits for pre-emption priority, \
                                                         0 bit  for subpriority */

/* Power */
#define POWER_REGULATOR_VOLTAGE_SCALE3 0x01 /*!< Scale 3 mode: the maximum value of fHCLK is 120 MHz. */

/* GPIOs */
#define HIGH true /*!< Logic 1 */
#define LOW false /*!< Logic 0 */

#define GPIO_MODE_IN 0x00        /*!< GPIO as input */
#define GPIO_MODE_OUT 0x01       /*!< GPIO as output */
#define GPIO_MODE_ALTERNATE 0x02 /*!< GPIO as alternate function */
#define GPIO_MODE_ANALOG 0x03    /*!< GPIO as analog */

#define GPIO_PUPDR_NOPULL 0x00 /*!< GPIO no pull up or down */
#define GPIO_PUPDR_PUP 0x01    /*!< GPIO pull up */
#define GPIO_PUPDR_PDOWN 0x02  /*!< GPIO pull down */

/* Interruption */
#define TRIGGER_RISING_EDGE 0x01U                                      /*!< Interrupt mask for detecting rising edge */
#define TRIGGER_FALLING_EDGE 0x02U                                     /*!< Interrupt mask for detecting falling edge */
#define TRIGGER_BOTH_EDGE (TRIGGER_RISING_EDGE | TRIGGER_FALLING_EDGE) /*!< Interrupt mask for detecting both rising and falling edges */
#define TRIGGER_ENABLE_EVENT_REQ 0x04U                                 /*!< Interrupt mask to enable event requests */
#define TRIGGER_ENABLE_INTERR_REQ 0x08U                                /*!< Interrupt mask to enable interrupt request */

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief  This function is based on the initialization of the HAL Library; it must be the first
 *         thing to be executed in the main program (before to call any other
 *          functions), it performs the following:
 *           - Configure the Flash prefetch, instruction and Data caches.
 *           - Configures the SysTick to generate an interrupt each 1 millisecond, which is clocked by the HSI (at this stage, the clock is not yet configured and thus the system is running from the internal HSI at 16 MHz).
 *           - Set NVIC Group Priority to 4.
 *             NVIC_PRIORITYGROUP_4: 4 bits for preemption priority
 *                                    0 bits for subpriority
 *           - Configure the system clock
 *
 * @note   SysTick is used as time base for the delay functions. When using the HAL, the application
 *         needs to ensure that the SysTick time base is always set to 1 millisecond
 *         to have correct HAL operation.
 *    When the NVIC_PRIORITYGROUP_0 is selected, IRQ preemption is no more possible.
 *         The pending IRQ priority will be managed only by the subpriority.
 * @retval Init status
 */
size_t port_system_init(void);

/**
 * @brief Get the count of the System tick in milliseconds
 *
 * @return uint32_t count
 */
uint32_t port_system_get_millis(void);

/**
 * @brief Sets the number of milliseconds since the system started.
 *
 * @param ms new number of milliseconds since the system started.
º */
void port_system_set_millis(uint32_t ms);

/**
 * @brief Wait for some milliseconds
 *
 * @param ms number of milliseconds to wait
 */
void port_system_delay_ms(uint32_t ms);

/**
 * @brief Wait for some milliseconds from a time reference.
 *
 * @param p_t pointer to the time reference
 * @param ms number of milliseconds to wait
 */
void port_system_delay_until_ms(uint32_t *p_t, uint32_t ms);

/** @verbatim
      ==============================================================================
                              ##### How to use GPIOs #####
      ==============================================================================
      [..]
        (#) Enable the GPIO AHB clock using the RCC->AHB1ENR register.

        (#) Configure the GPIO pin.
            (++) Configure the IO mode.
            (++) Activate Pull-up, Pull-down resistor.
            (++) In case of Output or alternate function mode, configure the speed if needed.
            (++) Configure digital or analog mode.
            (++) In case of external interrupt/event select the type (interrupt or event) and
                 the corresponding trigger event (rising or falling or both).

        (#) In case of external interrupt/event mode selection, configure NVIC IRQ priority
            mapped to the EXTI line and enable it using.

        (#) To get the level of a pin configured in input mode use the GPIOx_IDR register.

        (#) To set/reset the level of a pin configured in output mode use the GPIOx_BSRR register
            to SET (bits 0..15) or RESET (bits 16..31) the GPIO.

        @endverbatim
      ******************************************************************************
      */
/**
 * @brief Configure the mode and pull of a GPIO
 *
 * @param p_port port of the GPIO (CMSIS struct like)
 * @param pin pin/line of the GPIO (index from 0 to 15)
 * @param mode input, output, alternate, or analog
 * @param pupd pull-up, pull-down, or no-pull
 */
void port_system_gpio_config(GPIO_TypeDef *p_port, uint8_t pin, uint8_t mode, uint8_t pupd);

/**
 * @brief Configure the alternate function of a GPIO
 *
 * @param p_port port of the GPIO (CMSIS struct like)
 * @param pin pin/line of the GPIO (index from 0 to 15)
 * @param alternate alternate function number (values from 0 to 15) according to table of the datasheet: "Table 11. Alternate function".
 */
void port_system_gpio_config_alternate(GPIO_TypeDef *p_port, uint8_t pin, uint8_t alternate);

/**
 * @brief Configure the external interruption or event of a GPIO
 *
 * @param p_port port of the GPIO (CMSIS struct like)
 * @param pin pin/line of the GPIO (index from 0 to 15)
 * @param mode trigger mode can be a combination (OR) of: (i) direction: rising edge (0x01), falling edge (0x02), (ii)  event request (0x04), or (iii) interrupt request (0x08).
 */
void port_system_gpio_config_exti(GPIO_TypeDef *p_port, uint8_t pin, uint32_t mode);

/**
 * @brief Enable interrupts of a GPIO line (pin)
 *
 * @param pin pin/line of the GPIO (index from 0 to 15)
 * @param priority priority level (from highest priority: 0, to lowest priority: 15)
 * @param subpriority subpriority level (from highest priority: 0, to lowest priority: 15)
 */
void port_system_gpio_exti_enable(uint8_t pin, uint8_t priority, uint8_t subpriority);

/**
 * @brief Disable interrupts of a GPIO line (pin)
 *
 * @param pin pin/line of the GPIO (index from 0 to 15)
 */
void port_system_gpio_exti_disable(uint8_t pin);

/**
 * @brief Returns the value of the IDR register
 *
 * @param p_port port of the GPIO (CMSIS struct like)
 * @param pin pin/line of the GPIO (index from 0 to 15)
 *
 * @retval boolean: true or false
 */
bool port_system_gpio_read(GPIO_TypeDef *p_port, uint8_t pin);

/**
 * @brief Sets the corresponding bit value of the BSRR register
 *
 * @param value boolean value to set the GPIO to HIGH(1, true) or LOW(0, false)
 * @param p_port port of the GPIO (CMSIS struct like)
 * @param pin pin/line of the GPIO (index from 0 to 15)
 */
void port_system_gpio_write(GPIO_TypeDef *p_port, uint8_t pin, bool value);

/**
 * @brief Writes the opposite value in the GPIO
 *
 * @param p_port port of the GPIO (CMSIS struct like)
 * @param pin pin/line of the GPIO (index from 0 to 15)
 */
void port_system_gpio_toggle(GPIO_TypeDef *p_port, uint8_t pin);

/**
 * @brief Set the system in stop mode for low power consumption
 *
 */
void port_system_power_stop(void);	

/**
 * @brief Set the system in sleep mode for low power consumption
 *
 */
void port_system_power_sleep(void);	

/**
 * @brief Suspend Tick increment
 *
 */
void port_system_systick_suspend(void);	

/**
 * @brief Resume Tick increment
 *
 */
void port_system_systick_resume(void);	

/**
 * @brief Enable low power consumption in sleep mode
 *
 */
void port_system_sleep(void);

#endif /* PORT_SYSTEM_H_ */
