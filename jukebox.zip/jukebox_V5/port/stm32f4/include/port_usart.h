/**
 * @file port_usart.h
 * @brief Header for port_usart.c file.
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 03/2024
 */
#ifndef PORT_USART_H_
#define PORT_USART_H_

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx.h"

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define USART_0_ID 0                    /*!< USART identifier number*/
#define USART_0 USART3                  /*!< USART used */
#define USART_0_GPIO_TX GPIOB           /*!< GPIO port for TX */
#define USART_0_GPIO_RX GPIOC           /*!< GPIO port for RX */
#define USART_0_PIN_TX 10               /*!< GPIO pin for TX */
#define USART_0_PIN_RX 11               /*!< GPIO pin for RX */
#define USART_0_AF_TX 7                 /*!< Alternate function fot TX */
#define USART_0_AF_RX 7                 /*!< Alternate function fot RX */
#define USART_INPUT_BUFFER_LENGTH 10    /*!< USART input message length */
#define USART_OUTPUT_BUFFER_LENGTH 100  /*!< USART output message length */
#define EMPTY_BUFFER_CONSTANT 0x0       /*!< Empty buffer constant*/
#define END_CHAR_CONSTANT 0xA           /*!< End char constant*/

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Usart HW dependencies
 *
 */
typedef struct
{
    USART_TypeDef *p_usart;                             /*!< USART periphal */
    GPIO_TypeDef *p_port_tx;                            /*!< GPIO port of the USART TX */
    GPIO_TypeDef *p_port_rx;                            /*!< GPIO port of the USART RX */
    uint8_t pin_tx;                                     /*!< Pin of the USART TX */
    uint8_t pin_rx;                                     /*!< Pin of the USART RX */
    uint8_t alt_func_tx;                                /*!< Alternate function of TX */
    uint8_t alt_func_rx;                                /*!< Alternate function of RX */
    char input_buffer[USART_INPUT_BUFFER_LENGTH];       /*!< Input buffer */
    uint8_t i_idx;                                      /*!< Index of the input buffer */
    bool read_complete;                                 /*!< Flag that indicates if the data has been sent*/
    char output_buffer[USART_OUTPUT_BUFFER_LENGTH];     /*!< Output buffer */
    uint8_t o_idx;                                      /*!< index of the output buffer */
    bool write_complete;                                /*!< Flag that indicates if the data has been sent*/
} port_usart_hw_t;

/* Global variables */
/**
 * @brief Array of usart HW characteristics
 *
 */
extern port_usart_hw_t usart_arr[];

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief Copy the message to the output buffer of the USART.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 * @param p_data pointer to the message
 * @param length length of the message
 */
void port_usart_copy_to_output_buffer(uint32_t usart_id, char *p_data, uint32_t length);

/**
 * @brief Disable USART RX interrupt.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_disable_rx_interrupt(uint32_t usart_id);

/**
 * @brief Disable USART TX interrupt.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_disable_tx_interrupt(uint32_t usart_id);

/**
 * @brief Enable USART RX interrupt.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_enable_rx_interrupt(uint32_t usart_id);

/**
 * @brief Enable USART TX interrupt.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_enable_tx_interrupt(uint32_t usart_id);

/**
 * @brief Configure the specifications of the USART
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_init(uint32_t usart_id);

/**
 * @brief Check if a transmission is complete.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 *
 * @return boolean: true (transmission complete) or false (transmission pending)
 */
bool port_usart_tx_done(uint32_t usart_id);

/**
 * @brief Check if a reception is complete.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 *
 * @return boolean: true (reception complete) or false (reception pending)
 */
bool port_usart_rx_done(uint32_t usart_id);

/**
 * @brief Get the message received through the USART and store it in the buffer.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 * @param p_buffer pointer to the buffer where the message will be stored
 */
void port_usart_get_from_input_buffer(uint32_t usart_id, char *p_buffer);

/**
 * @brief Check if the USART is ready to receive a new message.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 *
 * @return boolean: true (ready to receive) or false (not ready)
 */
bool port_usart_get_txr_status(uint32_t usart_id);

/**
 * @brief Reset the input buffer of the USART.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_reset_input_buffer(uint32_t usart_id);

/**
 * @brief Reset the output buffer of the USART.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_reset_output_buffer(uint32_t usart_id);

/**
 * @brief Function to read the data from the USART Data Register and store it in the input buffer.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_store_data(uint32_t usart_id);

/**
 * @brief Function to write the data from the output buffer to the USART Data Register.
 *
 * @param usart_id index used to select the element of the usart_arr[]
 */
void port_usart_write_data(uint32_t usart_id);

#endif