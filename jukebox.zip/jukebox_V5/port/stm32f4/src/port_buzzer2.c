/**
 * @file port_buzzer2.c
 * @brief Portable functions to interact with the Buzzer 2 melody player FSM library.
 * @remark This file is created in V5
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 05/2024
 */
/* Includes ------------------------------------------------------------------*/
#include <math.h>
#include "port_buzzer2.h"

/* Defines -------------------------------------------------------------------*/
#define ALT_FUNC2_TIM3

/* Global variables */
port_buzzer_hw_t2 buzzers_arr2[]={
  [BUZZER_1_ID]={
    .p_port2 = BUZZER_1_GPIO,
    .pin2 = BUZZER_1_PIN,
    .alt_func2 = BUZZER_1_AF,
    .note_end2 = false
  },
};

/* Private functions */

/**
 * @brief Configure the timer that controls the duration of the note
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 */
static void _timer_duration_setup2(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_1_ID)
  {
    RCC->APB1ENR |= RCC_APB1ENR_TIM5EN;
    TIM5->CR1 &= ~TIM_CR1_CEN;
    TIM5->CR1 |= TIM_CR1_ARPE;
    TIM5->SR &= ~TIM_SR_UIF;
    TIM5->DIER |= TIM_DIER_UIE;
    /* Configure interruptions */
    NVIC_SetPriority(TIM5_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 3, 0));
    NVIC_EnableIRQ(TIM5_IRQn);
  }
}

/**
 * @brief Configure the timer that controls the PWM of the buzzer
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 */
static void _timer_pwm_setup2(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_1_ID){
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
    TIM4->CR1 &= ~TIM_CR1_CEN; 
    TIM4->CR1 |= TIM_CR1_ARPE; 
    TIM4->CNT = 0;
    TIM4->ARR = 0;
    TIM4->PSC = 0;
    TIM4->EGR |= TIM_EGR_UG;
    TIM4->CCER &= ~TIM_CCER_CC1E;
    TIM4->CCMR1 |= (TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2);
    TIM4->CCMR1 |= TIM_CCMR1_OC1PE;
  }
}

/* Public functions -----------------------------------------------------------*/

void port_buzzer_init2(uint32_t buzzer_id)
{
  port_buzzer_hw_t2 buzzer = buzzers_arr2[buzzer_id];
  GPIO_TypeDef *p_port = buzzer.p_port2;
  uint8_t pin = buzzer.pin2;
  uint8_t alt_func = buzzer.alt_func2;
  
  port_system_gpio_config(p_port,pin,GPIO_MODE_ALTERNATE,GPIO_PUPDR_NOPULL);
  port_system_gpio_config_alternate(p_port,pin,alt_func);
  _timer_duration_setup2(buzzer_id);
  _timer_pwm_setup2(buzzer_id);
}

void port_buzzer_set_note_duration2(uint32_t buzzer_id, uint32_t duration_ms)
{
  if (buzzer_id == BUZZER_1_ID)
  {
  TIM5->CR1 &= ~TIM_CR1_CEN;
  TIM5->CNT = 0;
  double sysclk_as_double = (double)SystemCoreClock;
  double s_as_double = (double)(duration_ms/1000.0);
  double psc_as_double = round(((sysclk_as_double*s_as_double)/(65535.0 + 1.0))-2.0);
  double arr_double = 0.0;
  do{
  psc_as_double ++;
  arr_double = round(((sysclk_as_double*s_as_double)/(psc_as_double + 1.0))-1.0);
  }
  while(arr_double>65535.0);
  TIM5->ARR = (uint32_t)(round(arr_double));
  TIM5->PSC = (uint32_t)(round(psc_as_double));
  TIM5->EGR |= TIM_EGR_UG;
  buzzers_arr2[buzzer_id].note_end2 = false;
  TIM5->CR1 |= TIM_CR1_CEN;
  }
}
void port_buzzer_set_note_frequency2(uint32_t buzzer_id, double frequency_hz)
{
  if (buzzer_id == BUZZER_1_ID)
  {
  if(frequency_hz == 0){
    TIM4->CR1 &= ~TIM_CR1_CEN;
    return;
  }
  
  TIM4->CR1 &= ~TIM_CR1_CEN;
  TIM4->CNT = 0;
  double sysclk_as_double = (double)SystemCoreClock;
  double s_as_double = (double)(1/frequency_hz);
  double psc_as_double = round(((sysclk_as_double*s_as_double)/(65535.0 + 1.0))-2.0);
  double arr_double = 0.0;
  do{
  psc_as_double ++;
  arr_double = round(((sysclk_as_double*s_as_double)/(psc_as_double + 1.0))-1.0);
  }
  while(arr_double>65535.0);
  TIM4->ARR = (uint32_t)(round(arr_double));
  TIM4->PSC = (uint32_t)(round(psc_as_double));
  double ccr1_double = BUZZER_PWM_DC2 * (arr_double +1);
  TIM4->CCR1 = (uint32_t)(round(ccr1_double));
  TIM4->EGR |= TIM_EGR_UG;
  TIM4->CCER |= TIM_CCER_CC1E;
  TIM4->CR1 |= TIM_CR1_CEN;
  }
}

bool port_buzzer_get_note_timeout2(uint32_t buzzer_id)
{
  if (buzzer_id ==BUZZER_1_ID){
    return buzzers_arr2[buzzer_id].note_end2;
  }else{return false;}
}
void port_buzzer_stop2(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_1_ID){
    TIM4->CR1 &= ~TIM_CR1_CEN;
    TIM5->CR1 &= ~TIM_CR1_CEN;
  }
}
