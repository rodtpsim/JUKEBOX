/**
 * @file port_buzzer.c
 * @brief Portable functions to interact with the Buzzer melody player FSM library.
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 04/2024
 */

/* Includes ------------------------------------------------------------------*/
#include <math.h>
#include "port_buzzer.h"

/* Defines -------------------------------------------------------------------*/
#define ALT_FUNC2_TIM3

/* Global variables */
port_buzzer_hw_t buzzers_arr[] = {
    [BUZZER_0_ID] = {
        .p_port = BUZZER_0_GPIO,
        .pin = BUZZER_0_PIN,
        .alt_func = BUZZER_0_AF,
        .note_end = false},
};

/* Private functions */
/**
 * @brief Configure the timer that controls the duration of the note
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 */
static void _timer_duration_setup(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_0_ID)
  {
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->CR1 &= ~TIM_CR1_CEN;
    TIM2->CR1 |= TIM_CR1_ARPE;
    TIM2->SR &= ~TIM_SR_UIF;
    TIM2->DIER |= TIM_DIER_UIE;
    /* Configure interruptions */
    NVIC_SetPriority(TIM2_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 3, 0));
    NVIC_EnableIRQ(TIM2_IRQn);
  }
}

/**
 * @brief Configure the timer that controls the PWM of the buzzer
 *
 * @param buzzer_id index used to select the element of the buzzer_arr[]
 */
static void _timer_pwm_setup(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_0_ID)
  {
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
    TIM3->CR1 &= ~TIM_CR1_CEN;
    TIM3->CR1 |= TIM_CR1_ARPE;
    TIM3->CNT = 0;
    TIM3->ARR = 0;
    TIM3->PSC = 0;
    TIM3->EGR |= TIM_EGR_UG;
    TIM3->CCER &= ~TIM_CCER_CC1E;
    TIM3->CCMR1 |= (TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2);
    TIM3->CCMR1 |= TIM_CCMR1_OC1PE;
  }
}

/* Public functions -----------------------------------------------------------*/

void port_buzzer_init(uint32_t buzzer_id)
{
  port_buzzer_hw_t buzzer = buzzers_arr[buzzer_id];

  GPIO_TypeDef *p_port = buzzer.p_port;
  uint8_t pin = buzzer.pin;
  uint8_t alt_func = buzzer.alt_func;

  port_system_gpio_config(p_port, pin, GPIO_MODE_ALTERNATE, GPIO_PUPDR_NOPULL);
  port_system_gpio_config_alternate(p_port, pin, alt_func);
  _timer_duration_setup(buzzer_id);
  _timer_pwm_setup(buzzer_id);
}

void port_buzzer_set_note_duration(uint32_t buzzer_id, uint32_t duration_ms)
{
  if (buzzer_id == BUZZER_0_ID)
  {
    TIM2->CR1 &= ~TIM_CR1_CEN;
    TIM2->CNT = 0;
    double sysclk_as_double = (double)SystemCoreClock;
    double s_as_double = (double)(duration_ms / 1000.0);
    
    double psc_as_double = round(((sysclk_as_double * s_as_double) / (65535.0 + 1.0)) - 2.0);
    double arr_double = 0.0;
    do
    {
      psc_as_double++;
      arr_double = round(((sysclk_as_double * s_as_double) / (psc_as_double + 1.0)) - 1.0);
    } while (arr_double > 65535.0);
    
   /*
    double psc_as_double = round(((sysclk_as_double * s_as_double) / (65535.0 + 1.0)) - 1.0);
    double arr_double = round(((sysclk_as_double*s_as_double)/(psc_as_double + 1.0))-1.0);

    if(arr_double>65535.0){
      psc_as_double += 1;
      arr_double = round(((sysclk_as_double*s_as_double)/(psc_as_double + 1.0)) -1.0);
    }
    */
    TIM2->ARR = (uint32_t)(round(arr_double));
    TIM2->PSC = (uint32_t)(round(psc_as_double));
    TIM2->EGR |= TIM_EGR_UG;
    
    buzzers_arr[buzzer_id].note_end = false;
    TIM2->CR1 |= TIM_CR1_CEN;
  }
}

void port_buzzer_set_note_frequency(uint32_t buzzer_id, double frequency_hz)
{
  if (buzzer_id == BUZZER_0_ID)
  {
    if (frequency_hz == 0)
    {
      TIM3->CR1 &= ~TIM_CR1_CEN;
      return;
    }

    TIM3->CR1 &= ~TIM_CR1_CEN;
    TIM3->CNT = 0;
    double sysclk_as_double = (double)SystemCoreClock;
    double s_as_double = (double)(1 / frequency_hz);
    double psc_as_double = round(((sysclk_as_double * s_as_double) / (65535.0 + 1.0)) - 2.0);
    double arr_double = 0.0;
    do
    {
      psc_as_double++;
      arr_double = round(((sysclk_as_double * s_as_double) / (psc_as_double + 1.0)) - 1.0);
    } while (arr_double > 65535.0);
    TIM3->ARR = (uint32_t)(round(arr_double));
    TIM3->PSC = (uint32_t)(round(psc_as_double));
    double ccr1_double = BUZZER_PWM_DC * (arr_double + 1);
    TIM3->CCR1 = (uint32_t)(round(ccr1_double));
    TIM3->EGR |= TIM_EGR_UG;
    TIM3->CCER |= TIM_CCER_CC1E;
    TIM3->CR1 |= TIM_CR1_CEN;
  }
}

bool port_buzzer_get_note_timeout(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_0_ID)
  {
    return buzzers_arr[buzzer_id].note_end;
  }
  else
  {
    return false;
  }
}
void port_buzzer_stop(uint32_t buzzer_id)
{
  if (buzzer_id == BUZZER_0_ID)
  {
    TIM3->CR1 &= ~TIM_CR1_CEN;
    TIM2->CR1 &= ~TIM_CR1_CEN;
  }
}
