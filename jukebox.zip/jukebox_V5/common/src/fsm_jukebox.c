/**
 * @file fsm_jukebox.c
 * @brief Jukebox FSM main file.
 * @remark This file is modified in V5
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gomez Fernandez-Getino
 * @date 05/2024
 */

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fsm.h"
#include "fsm_jukebox.h"
#include "fsm_button.h"
#include "fsm_usart.h"
#include "fsm_buzzer.h"
#include "fsm_buzzer2.h"
#include "port_system.h"
#include "port_usart.h"

/* Defines ------------------------------------------------------------------*/
#define MAX(a, b) ((a) > (b) ? (a) : (b)) /*!< Macro to get the maximum of two values. */

/* Private functions */
/**
 * @brief Parse the message received by the USART.
 *
 * @param p_message pointer to the message received by the USART
 * @param p_command pointer to store the command extracted from the message
 * @param p_param pointer to store the parameter extracted from the message
 *
 * @return boolean: true (the message has been parsed correctly) or false (the message has not been parsed correctly)
 */
bool _parse_message(char *p_message, char *p_command, char *p_param)
{
    char *p_token = strtok(p_message, " "); // Split the message by space

    // If there's a token (command), copy it to the command variable
    if (p_token != NULL)
    {
        strcpy(p_command, p_token);
    }
    else
    {
        // No command found, you might return an error or handle it as needed
        // The USART driver of the computer sends an empty at initialization, so we will ignore it
        return false;
    }

    // Extract the parameter (if available)
    p_token = strtok(NULL, " "); // Get the next token

    if (p_token != NULL)
    {
        strcpy(p_param, p_token);
    }
    else
    {
        strcpy(p_param, " "); // NO param found
    }
    return true;
}

/* State machine input or transition functions */
/**
 * @brief Set the next song to be played
 *
 * @remark This function is modified in V5
 * 
 * @param p_fsm_jukebox pointer to the jukebox fsm
 */
void _set_next_song(fsm_jukebox_t *p_fsm_jukebox)
{
    fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, STOP);
    fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, STOP2);    //V5
    p_fsm_jukebox->melody_idx++;
    if (p_fsm_jukebox->melody_idx >= MELODIES_MEMORY_SIZE)
    {
        p_fsm_jukebox->melody_idx = 0;
    }
    if ((p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx].melody_length <= 0) || 
        (p_fsm_jukebox->melodies2[p_fsm_jukebox->melody_idx].melody_length <= 0))    //V5
    {
        p_fsm_jukebox->melody_idx = 0;
        p_fsm_jukebox->p_melody = p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx].p_name;
        p_fsm_jukebox->p_melody2 = p_fsm_jukebox->melodies2[p_fsm_jukebox->melody_idx].p_name;  //V5
    }
    printf("Playing: %s\n", p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx].p_name);
    fsm_buzzer_set_melody(p_fsm_jukebox->p_fsm_buzzer, &p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx]);
    fsm_buzzer_set_melody2(p_fsm_jukebox->p_fsm_buzzer2, &p_fsm_jukebox->melodies2[p_fsm_jukebox->melody_idx]); //V5 
    fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, PLAY);
    fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, PLAY2);    //V5
}

/**
 * @brief Check if the button has been pressed for the required time to turn ON the jukebox
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_on(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    uint32_t f = fsm_button_get_duration(p_fsm->p_fsm_button);
    if ((f > 0) && (f > p_fsm->on_off_press_time_ms))
    {
        return true;
    }
    else
        return false;
}

/**
 * @brief Check if the button has been pressed for the required time to turn OFF the jukebox
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_off(fsm_t *p_this)
{
    return check_on(p_this);
}

/**
 * @brief Check if the buzzer has finished the current melody
 * 
 * @remark This function is modified in V5
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_melody_finished(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    if ((fsm_buzzer_get_action(p_fsm->p_fsm_buzzer) == STOP) &&     
        (fsm_buzzer_get_action2(p_fsm->p_fsm_buzzer2) == STOP2)) //V5
    {
        return true;
    }
    else
        return false;
}

/**
 * @brief Check if the button has been pressed for the required time to load the next song
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_next_song_button(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    uint32_t f = fsm_button_get_duration(p_fsm->p_fsm_button);
    if ((f > 0) && (f > p_fsm->next_song_press_time_ms) && (f < p_fsm->on_off_press_time_ms))
    {
        return true;
    }
    else
        return false;
}

/**
 * @brief Check if the usart has received data
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_command_received(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    return fsm_usart_check_data_received(p_fsm->p_fsm_usart);
}

/**
 * @brief Check if any element of the system is active
 * 
 * @remark This function is modified in V5
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_activity(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    return ((fsm_button_check_activity(p_fsm->p_fsm_button)) || (fsm_usart_check_activity(p_fsm->p_fsm_usart)) || (fsm_buzzer_check_activity(p_fsm->p_fsm_buzzer)) || 
            (fsm_buzzer_check_activity2(p_fsm->p_fsm_buzzer2)));  //V5
}

/**
 * @brief Check if no element of the system is active
 *
 * @param p_this pointer to an fsm_t struct
 *
 * @return boolean: true or false
 */
static bool check_no_activity(fsm_t *p_this)
{
    return !check_activity(p_this);
}

/* State machine output or action functions */
/**
 * @brief execute the following command received from the Usart
 *
 * @remark This function is modified in V5
 * 
 * @param p_fsm_jukebox pointer to the jukebox fsm
 * @param p_command	Pointer to the command to be executed
 * @param p_param	Pointer to the parameter of the command to be executed
 */
void _execute_command(fsm_jukebox_t *p_fsm_jukebox, char *p_command, char *p_param)
{
    if (strcmp(p_command, "play") == 0)
    {
        fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, PLAY);
        fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, PLAY2);    //V5
        return;
    }
    else
    {
        if (strcmp(p_command, "stop") == 0)
        {
            fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, STOP);
            fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, STOP2);    //V5
            return;
        }
        else
        {
            if (strcmp(p_command, "pause") == 0)
            {
                fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, PAUSE);
                fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, PAUSE2);   //V5
                return;
            }
            else
            {
                if (strcmp(p_command, "speed") == 0)
                {
                    double param = atof(p_param);
                    fsm_buzzer_set_speed(p_fsm_jukebox->p_fsm_buzzer, MAX(param, 0.1));
                    fsm_buzzer_set_speed2(p_fsm_jukebox->p_fsm_buzzer2, MAX(param, 0.1));   //V5
                    return;
                }
                else
                {
                    if (strcmp(p_command, "next") == 0)
                    {
                        _set_next_song(p_fsm_jukebox);
                        p_fsm_jukebox->p_melody = p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx].p_name;
                        p_fsm_jukebox->p_melody2 = p_fsm_jukebox->melodies2[p_fsm_jukebox->melody_idx].p_name;  //V5
                        return;
                    }
                    else
                    {
                        if (strcmp(p_command, "select") == 0)
                        {
                            uint32_t melody_selected = atoi(p_param);
                            if (p_fsm_jukebox->melodies[melody_selected].melody_length != 0)
                            {
                                fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, STOP);
                                fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, STOP2);                                                    //V5
                                p_fsm_jukebox->melody_idx = (uint8_t)melody_selected;
                                fsm_buzzer_set_melody(p_fsm_jukebox->p_fsm_buzzer, &p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx]);
                                fsm_buzzer_set_melody2(p_fsm_jukebox->p_fsm_buzzer2, &p_fsm_jukebox->melodies2[p_fsm_jukebox->melody_idx]);     //V5
                                p_fsm_jukebox->p_melody = p_fsm_jukebox->melodies[p_fsm_jukebox->melody_idx].p_name;
                                p_fsm_jukebox->p_melody2 = p_fsm_jukebox->melodies2[p_fsm_jukebox->melody_idx].p_name;                          //V5
                                fsm_buzzer_set_action(p_fsm_jukebox->p_fsm_buzzer, PLAY);
                                fsm_buzzer_set_action2(p_fsm_jukebox->p_fsm_buzzer2, PLAY2);                                                    //V5
                                return;
                            }
                            else
                            {
                                char msg3[USART_OUTPUT_BUFFER_LENGTH];
                                sprintf(msg3, "Error: Melody not found\n");
                                fsm_usart_set_out_data(p_fsm_jukebox->p_fsm_usart, msg3);
                                return;
                            }
                        }
                        else
                        {
                            if (strcmp(p_command, "info") == 0)
                            {
                                char msg[USART_OUTPUT_BUFFER_LENGTH];
                                sprintf(msg, "Playing: %s\n", p_fsm_jukebox->p_melody);
                                fsm_usart_set_out_data(p_fsm_jukebox->p_fsm_usart, msg);
                                return;
                            }
                            else
                            {
                                char msg2[USART_OUTPUT_BUFFER_LENGTH];
                                sprintf(msg2, "Error: Command not found\n");
                                fsm_usart_set_out_data(p_fsm_jukebox->p_fsm_usart, msg2);
                                return;
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * @brief Initialize the Jukebox by playing the intro melody
 * 
 * @remark This function is modified in V5
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_start_up(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    fsm_button_reset_duration(p_fsm->p_fsm_button);
    fsm_usart_enable_rx_interrupt(p_fsm->p_fsm_usart);
    printf("Jukebox ON\n");
    fsm_buzzer_set_speed(p_fsm->p_fsm_buzzer, 1.0);
    fsm_buzzer_set_speed2(p_fsm->p_fsm_buzzer2, 1.0);                       //V5
    fsm_buzzer_set_melody(p_fsm->p_fsm_buzzer, &p_fsm->melodies[0]);
    fsm_buzzer_set_melody2(p_fsm->p_fsm_buzzer2, &p_fsm->melodies2[0]);     //V5
    fsm_buzzer_set_action(p_fsm->p_fsm_buzzer, PLAY);
    fsm_buzzer_set_action2(p_fsm->p_fsm_buzzer2, PLAY2);                    //V5
    fsm_button_reset_duration(p_fsm->p_fsm_button);
}

/**
 * @brief After the intro melody, start the Jukebox.
 * 
 * @remark This function is modified in V5
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_start_jukebox(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    p_fsm->melody_idx = 0;
    p_fsm->p_melody = p_fsm->melodies[p_fsm->melody_idx].p_name;
    p_fsm->p_melody2 = p_fsm->melodies2[p_fsm->melody_idx].p_name;  //V5
}

/**
 * @brief Turn off the jukebox
 *
 * @remark This function is modified in V5
 * 
 * @param p_this pointer to an fsm_t struct
 */
static void do_stop_jukebox(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    fsm_button_reset_duration(p_fsm->p_fsm_button);
    fsm_usart_disable_rx_interrupt(p_fsm->p_fsm_usart);
    fsm_usart_disable_tx_interrupt(p_fsm->p_fsm_usart);
    printf("Jukebox OFF\n");

    fsm_buzzer_set_action(p_fsm->p_fsm_buzzer, STOP);
    fsm_buzzer_set_action2(p_fsm->p_fsm_buzzer2, STOP2);                    //V5
    fsm_buzzer_set_speed(p_fsm->p_fsm_buzzer, 1.0);
    fsm_buzzer_set_speed2(p_fsm->p_fsm_buzzer2, 1.0);                       //V5
    fsm_buzzer_set_melody(p_fsm->p_fsm_buzzer, &p_fsm->melodies[1]);
    fsm_buzzer_set_melody2(p_fsm->p_fsm_buzzer2, &p_fsm->melodies2[1]);     //V5
    fsm_buzzer_set_action(p_fsm->p_fsm_buzzer, PLAY);
    fsm_buzzer_set_action2(p_fsm->p_fsm_buzzer2, PLAY2);                    //V5

    fsm_button_reset_duration(p_fsm->p_fsm_button);
}

/**
 * @brief Load the next song
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_load_next_song(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    _set_next_song(p_fsm);
    fsm_button_reset_duration(p_fsm->p_fsm_button);
}

/**
 * @brief Read the command from the usart
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_read_command(fsm_t *p_this)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    char p_message[USART_INPUT_BUFFER_LENGTH];
    char p_command[USART_INPUT_BUFFER_LENGTH];
    char p_param[USART_INPUT_BUFFER_LENGTH];
    fsm_usart_get_in_data(p_fsm->p_fsm_usart, p_message);
    bool a = _parse_message(p_message, p_command, p_param);
    if (a)
    {
        _execute_command(p_fsm, p_command, p_param);
    }
    fsm_usart_reset_input_data(p_fsm->p_fsm_usart);
}

/**
 * @brief While the Jukebox is OFF start the low power mode
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_sleep_while_off(fsm_t *p_this)
{
    port_system_sleep();
}

/**
 * @brief While the Jukebox is ON start the low power mode
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_sleep_while_on(fsm_t *p_this)
{
    port_system_sleep();
}

/**
 * @brief While the Jukebox is waiting for a command from the usart start the low power mode
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_sleep_wait_command(fsm_t *p_this)
{
    port_system_sleep();
}

/**
 * @brief While the Jukebox is OFF start the low power mode
 *
 * @param p_this pointer to an fsm_t struct
 */
static void do_sleep_off(fsm_t *p_this)
{
    port_system_sleep();
}

/**
 * @brief Jukebox FSM transition table
 *
 * @image html jukebox_trans.png
 *
 */
fsm_trans_t fsm_trans_jukebox[] = {
    {OFF, check_no_activity, SLEEP_WHILE_OFF, do_sleep_off},
    {SLEEP_WHILE_OFF, check_no_activity, SLEEP_WHILE_OFF, do_sleep_while_off},
    {SLEEP_WHILE_OFF, check_activity, OFF, NULL},
    {OFF, check_on, START_UP, do_start_up},
    {START_UP, check_melody_finished, WAIT_COMMAND, do_start_jukebox},
    {WAIT_COMMAND, check_next_song_button, WAIT_COMMAND, do_load_next_song},
    {WAIT_COMMAND, check_command_received, WAIT_COMMAND, do_read_command},
    {WAIT_COMMAND, check_no_activity, SLEEP_WHILE_ON, do_sleep_wait_command},
    {SLEEP_WHILE_ON, check_no_activity, SLEEP_WHILE_ON, do_sleep_while_on},
    {SLEEP_WHILE_ON, check_activity, WAIT_COMMAND, NULL},
    {WAIT_COMMAND, check_off, OFF, do_stop_jukebox},
    {-1, NULL, -1, NULL}};


/* Public functions */
fsm_t *fsm_jukebox_new(fsm_t *p_fsm_button, uint32_t on_off_press_time_ms, fsm_t *p_fsm_usart, fsm_t *p_fsm_buzzer, fsm_t *p_fsm_buzzer2, uint32_t next_song_press_time_ms)
{
    fsm_t *p_fsm = malloc(sizeof(fsm_jukebox_t));

    fsm_jukebox_init(p_fsm, p_fsm_button, on_off_press_time_ms, p_fsm_usart, p_fsm_buzzer, p_fsm_buzzer2, next_song_press_time_ms); //V5 adds p_fsm_buzzer2

    return p_fsm;
}

void fsm_jukebox_init(fsm_t *p_this, fsm_t *p_fsm_button, uint32_t on_off_press_time_ms, fsm_t *p_fsm_usart, fsm_t *p_fsm_buzzer, fsm_t *p_fsm_buzzer2, uint32_t next_song_press_time_ms)
{
    fsm_jukebox_t *p_fsm = (fsm_jukebox_t *)(p_this);
    fsm_init(p_this, fsm_trans_jukebox); 
    p_fsm->p_fsm_button = p_fsm_button;
    p_fsm->on_off_press_time_ms = on_off_press_time_ms;
    p_fsm->p_fsm_usart = p_fsm_usart;
    p_fsm->p_fsm_buzzer = p_fsm_buzzer;
    p_fsm->p_fsm_buzzer2 = p_fsm_buzzer2;                       //V5
    p_fsm->next_song_press_time_ms = next_song_press_time_ms;
    p_fsm->melody_idx = 0;
    memset(p_fsm->melodies, 0, sizeof(p_fsm->melodies));
    memset(p_fsm->melodies2, 0, sizeof(p_fsm->melodies2));      //V5
    
    // Melodies to play on the buzzer 1
    p_fsm->melodies[0] = scale_melody;
    p_fsm->melodies[1] = inverted_scale_melody;         //V5
    p_fsm->melodies[2] = tetris_melody;
    p_fsm->melodies[3] = happy_birthday_melody;         
    p_fsm->melodies[4] = twinkle_melody;                //V5

    // Melodies to play on the buzzer 2
    p_fsm->melodies2[0] = scale_melody;                 //V5
    p_fsm->melodies2[1] = inverted_scale_melody;        //V5
    p_fsm->melodies2[2] = tetris_back_melody;           //V5
    p_fsm->melodies2[3] = hb_back_melody;               //V5
    p_fsm->melodies2[4] = twinkle_back_melody;          //V5
}
