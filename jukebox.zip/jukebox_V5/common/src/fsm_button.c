/**
 * @file fsm_button.c
 * @brief Button FSM main file.
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gomez Fernandez-Getino
 * @date 02/2024
 */

/* Includes ------------------------------------------------------------------*/
#include "fsm_button.h"
#include "port_button.h"
#include <stdlib.h>

/* Functions -----------------------------------------------------------------*/

/* Private Functions --------------------------------------------*/
/**
 * @brief Checks if the button is released
 *
 * @param p_this pointer to the fsm struct
 *
 * @return boolean: true (button released) or false (otherwise)
 */
static bool check_button_released(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    return !port_button_is_pressed(p_button->button_id);
}

/**
 * @brief Checks if the button is pressed
 *
 * @param p_this pointer to the fsm struct
 *
 * @return boolean: true (button pressed) or false (otherwise)
 */
static bool check_button_pressed(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    return port_button_is_pressed(p_button->button_id);
}

/**
 * @brief Checks if the debounce time has passed
 *
 * @param p_this pointer to the fsm struct
 *
 * @return boolean: true (current system time greater than the last debounce timeout) or false (otherwise)
 */
static bool check_timeout(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    uint32_t now = port_button_get_tick();
    return now > p_button->next_timeout;
}

/**
 * @brief Stores the current system time as the last time the button was pressed
 *
 * @param p_this pointer to the fsm struct
 */
static void do_store_tick_pressed(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    uint32_t now = port_button_get_tick();

    p_button->tick_pressed = now;
    p_button->next_timeout = now + p_button->debounce_time;
}

/**
 * @brief Computes the time since the last time the button has been pressed
 *
 * @param p_this pointer to the fsm struct
 */
static void do_set_duration(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    uint32_t now = port_button_get_tick();

    p_button->duration = now - p_button->tick_pressed;
    p_button->next_timeout = now + p_button->debounce_time;
}

/**
 * @brief Button FSM transition table
 * 
 * @image html button_trans.png
 */
static fsm_trans_t fsm_trans_button[] = {
    {BUTTON_RELEASED, check_button_pressed, BUTTON_PRESSED_WAIT, do_store_tick_pressed},
    {BUTTON_PRESSED_WAIT, check_timeout, BUTTON_PRESSED, NULL},
    {BUTTON_PRESSED, check_button_released, BUTTON_RELEASED_WAIT, do_set_duration},
    {BUTTON_RELEASED_WAIT, check_timeout, BUTTON_RELEASED, NULL},
    {-1, NULL, -1, NULL}};

/* Public Functions ---------------------------------------------*/
fsm_t *fsm_button_new(uint32_t debounce_time, uint32_t button_id)
{
    fsm_t *p_fsm = malloc(sizeof(fsm_button_t));
    fsm_button_init(p_fsm, debounce_time, button_id);
    return p_fsm;
}

void fsm_button_init(fsm_t *p_this, uint32_t debounce_time, uint32_t button_id)
{
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    fsm_init(p_this, fsm_trans_button);

    p_fsm->debounce_time = debounce_time;
    p_fsm->tick_pressed = 0;
    p_fsm->duration = 0;
    p_fsm->button_id = button_id;
    port_button_init(button_id); /* Initializes de button HW */
}

uint32_t fsm_button_get_duration(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    return p_button->duration;
}

void fsm_button_reset_duration(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    p_button->duration = 0;
}

bool fsm_button_check_activity(fsm_t *p_this)
{
    fsm_button_t *p_button = (fsm_button_t *)p_this;
    int f = p_button->f.current_state;
    if (f == BUTTON_RELEASED)
        return false;
    else
        return true;
}
