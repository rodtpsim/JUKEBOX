/**
 * @file melodies.c
 * @brief Melodies source file.
 * @author Rodrigo Tavares de Pina Simões
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 05/2024
 */

/* Includes ------------------------------------------------------------------*/
#include "melodies.h"

/* Melodies ------------------------------------------------------------------*/
// Melody Happy Birthday ----------------------------------------------------------------------------------------------------------------------------------------------
#define HAPPY_BIRTHDAY_LENGTH 25 /*!< Happy Birthday melody length */

/**
 * @brief Happy birthday melody notes.
 */
static const double happy_birthday_notes[HAPPY_BIRTHDAY_LENGTH] = {
    DO4, DO4, RE4, DO4, FA4, MI4, DO4, DO4, RE4, DO4, SOL4, FA4, DO4, DO4, DO5, LA4, FA4, MI4, RE4, LAs4, LAs4, LA4, FA4, SOL4, FA4};

/**
 * @brief Happy birthday melody durations in miliseconds.
 */
static const uint16_t happy_birthday_durations[HAPPY_BIRTHDAY_LENGTH] = {
    300, 100, 400, 400, 400, 800, 300, 100, 400, 400, 400, 800, 300, 100, 400, 400, 400, 400, 400, 300, 100, 400, 400, 400, 800};

/**
 * @brief Happy birthday melody struct.
 */
const melody_t happy_birthday_melody = {.p_name = "happy_birthday",
                                        .p_notes = (double *)happy_birthday_notes,
                                        .p_durations = (uint16_t *)happy_birthday_durations,
                                        .melody_length = HAPPY_BIRTHDAY_LENGTH};

#define HB_LENGTH 16 /*!< Happy Birthday melody length */

/**
 * @brief Happy birthday back melody notes.
 */
static const double hb_notes[HB_LENGTH] = {
    SILENCE, FA3, SILENCE, DO3, SILENCE, DO3, SILENCE, FA3, SILENCE, FA3, SILENCE, LAs3, SOL3, FA3, DO3, FA3};

/**
 * @brief Happy birthday back melody durations in miliseconds.
 */
static const uint16_t hb_durations[HB_LENGTH] = {
    400, 800, 400, 800, 400, 800, 400, 800, 400, 800, 400, 800, 400, 800, 400, 800};

/**
 * @brief Happy birthday back melody struct.
 */
const melody_t hb_back_melody = {.p_name = "",
                                        .p_notes = (double *)hb_notes,
                                        .p_durations = (uint16_t *)hb_durations,
                                        .melody_length = HB_LENGTH};

// Tetris melody ----------------------------------------------------------------------------------------------------------------------------------------------------------------
#define TETRIS_LENGTH 40 /*!< Tetris melody length */

/**
 * @brief Tetris melody notes.
 */
static const double tetris_notes[TETRIS_LENGTH] = {
    MI5, SI4, DO5, RE5, DO5, SI4, LA4, LA4, DO5, MI5, RE5, DO5, SI4, DO5, RE5, MI5, DO5, LA4,
    LA4, LA4, SI4, DO5, RE5, FA4, LA5, SOL5, FA5, MI5, DO5, MI5, RE5, DO5, SI4, SI4, LA4, RE5,
    MI5, DO5, LA4, LA4};

/**
 * @brief Tetris melody duration in miliseconds.
 */
static const uint16_t tetris_durations[TETRIS_LENGTH] = {
    400, 200, 200, 400, 200, 200, 400, 200, 200, 400, 200, 200, 600, 200, 400, 400, 400, 400, 200, 200, 200, 200,
    600, 200, 400, 200, 200, 600, 200, 400, 200, 200, 400, 200, 200, 400, 400, 400, 400, 400};

/**
 * @brief Tetris melody struct.
 */
const melody_t tetris_melody = {.p_name = "tetris",
                                .p_notes = (double *)tetris_notes,
                                .p_durations = (uint16_t *)tetris_durations,
                                .melody_length = TETRIS_LENGTH};
            
// Tetris backing melody
/**
 * @brief Tetris back melody notes.
 */
static const double tb_notes[TETRIS_LENGTH][3] = {
    {DO3, MI3, SOL3},  {DO3, MI3, SOL3},  {LA3, DO3, MI3}, {LA3, DO3, MI3},
    {FA3, LA3, DO4},   {FA3, LA3, DO4},   {RE3, FA3, LA3}, {RE3, FA3, LA3},
    {SI2, RE3, SOL3},  {SI2, RE3, SOL3},  {SOL2, SI2, RE3}, {SOL2, SI2, RE3},
    {MI3, SOL3, SI3},  {MI3, SOL3, SI3},  {RE3, FA3, LA3}, {RE3, FA3, LA3},
    {DO3, MI3, SOL3},  {DO3, MI3, SOL3},  {LA3, DO3, MI3}, {LA3, DO3, MI3},
    {FA3, LA3, DO4},   {FA3, LA3, DO4},   {RE3, FA3, LA3}, {RE3, FA3, LA3},
    {SI2, RE3, SOL3},  {SI2, RE3, SOL3},  {SOL2, SI2, RE3}, {SOL2, SI2, RE3},
    {MI3, SOL3, SI3},  {MI3, SOL3, SI3},  {RE3, FA3, LA3}, {RE3, FA3, LA3},
    {DO3, MI3, SOL3},  {DO3, MI3, SOL3},  {LA3, DO3, MI3}, {LA3, DO3, MI3},
    {FA3, LA3, DO4},   {FA3, LA3, DO4},   {RE3, FA3, LA3}, {RE3, FA3, LA3}
};

/**
 * @brief Tetris back melody durations in miliseconds.
 */
static const uint16_t tb_durations[TETRIS_LENGTH] = {
    400, 200, 400, 200, 400, 200, 400, 200,
    400, 200, 400, 200, 400, 200, 400, 200,
    400, 200, 400, 200, 400, 200, 400, 200,
    400, 200, 400, 200, 400, 200, 400, 200,
    400, 200, 400, 200, 400, 200, 400, 200
};
/**
 * @brief Tetris back melody struct.
 */
const melody_t tetris_back_melody = {.p_name = "",
                               .p_notes = (double *)tb_notes,
                               .p_durations = (uint16_t *)tb_durations,
                               .melody_length = TETRIS_LENGTH};

// Scale Melody-------------------------------------------------------------------------------------------------------------------------------------------
#define SCALE_MELODY_LENGTH 8   /*!< Scale melody length */

/**
 * @brief Scale melody notes.
 */
static const double scale_melody_notes[SCALE_MELODY_LENGTH] = {
    DO4, RE4, MI4, FA4, SOL4, LA4, SI4, DO5};

/**
 * @brief Scale melody durations in miliseconds.
 */
static const uint16_t scale_melody_durations[SCALE_MELODY_LENGTH] = {
    250, 250, 250, 250, 250, 250, 250, 250};

/**
 * @brief Scale melody struct.
 */
const melody_t scale_melody = {.p_name = "scale",
                               .p_notes = (double *)scale_melody_notes,
                               .p_durations = (uint16_t *)scale_melody_durations,
                               .melody_length = SCALE_MELODY_LENGTH};


//Inverted Scale Melody------------------------------------------------------------------------------------------------------------------------------------------------------------------

#define INVERTED_SCALE_MELODY_LENGTH 8 /*!< inverted_scale melody length */

/**
 * @brief Inverted scale melody notes.
 */
static const double inverted_scale_melody_notes[INVERTED_SCALE_MELODY_LENGTH] = {
    DO5, SI4, LA4, SOL4, FA4, MI4, RE4, DO4};

/**
 * @brief Inverted scale melody durations in miliseconds.
 */
static const uint16_t inverted_scale_melody_durations[INVERTED_SCALE_MELODY_LENGTH] = {
    250, 250, 250, 250, 250, 250, 250, 250};

/**
 * @brief Inverted scale melody struct.
 */
const melody_t inverted_scale_melody = {.p_name = "inverted_scale",
                               .p_notes = (double *)inverted_scale_melody_notes,
                               .p_durations = (uint16_t *)inverted_scale_melody_durations,
                               .melody_length = INVERTED_SCALE_MELODY_LENGTH};


// Twinkle Twinkle Little Star melody-------------------------------------------------------------------------------------------------------------------------------------------------------------
#define TWINKLE_MELODY_LENGTH 42    /*!< Twinkle melody length */

/**
 * @brief Twinkle melody notes.
 */
static const double twinkle_notes[TWINKLE_MELODY_LENGTH] = {
    DO5, DO5, SOL5, SOL5, LA5, LA5, SOL5,
    FA5, FA5, MI5, MI5, RE5, RE5, DO5,
    SOL5, SOL5, FA5, FA5, MI5, MI5, RE5,
    SOL5, SOL5, FA5, FA5, MI5, MI5, RE5,
    DO5, DO5, SOL5, SOL5, LA5, LA5, SOL5,
    FA5, FA5, MI5, MI5, RE5, RE5, DO5
};

/**
 * @brief Twinkle melody durations in miliseconds.
 */
static const uint16_t twinkle_durations[TWINKLE_MELODY_LENGTH] = {
    400, 400, 400, 400, 400, 400, 800,
    400, 400, 400, 400, 400, 400, 800,
    400, 400, 400, 400, 400, 400, 800,
    400, 400, 400, 400, 400, 400, 800,
    400, 400, 400, 400, 400, 400, 800,
    400, 400, 400, 400, 400, 400, 800
};

/**
 * @brief Twinkle melody struct.
 */
const melody_t twinkle_melody = {.p_name = "twinkle",
                               .p_notes = (double *)twinkle_notes,
                               .p_durations = (uint16_t *)twinkle_durations,
                               .melody_length = TWINKLE_MELODY_LENGTH};

// Twinkle Twinkle Little Star backing track
#define BACKING_MELODY_LENGTH 42 /*!< Backing track melody length */

/**
 * @brief Twinkle back melody notes.
 */
static const double ttb_notes[BACKING_MELODY_LENGTH] = {
    DO4,  DO4,  SOL4,  SOL4,  LA4,  LA4,  SOL4,  0,
    FA4,  FA4,  MI4,  MI4,  RE4,  RE4,  DO4,  0,
    SOL4,  SOL4,  FA4,  FA4,  MI4,  MI4,  RE4,  0,
    DO4,  DO4,  SOL4,  SOL4,  LA4,  LA4,  SOL4,  0,
    FA4,  FA4,  MI4,  MI4,  RE4,  RE4,  DO4,  0
};

/**
 * @brief Twinkle back melody durations in miliseconds.
 */
static const uint16_t ttb_durations[BACKING_MELODY_LENGTH] = {
    400, 400, 400, 400, 400, 400, 800, 800,
    400, 400, 400, 400, 400, 400, 800, 800,
    400, 400, 400, 400, 400, 400, 800, 800,
    400, 400, 400, 400, 400, 400, 800, 800,
    400, 400, 400, 400, 400, 400, 800, 800
};

/**
 * @brief Twinkle back melody struct.
 */
const melody_t twinkle_back_melody = {
    .p_name = "",
    .p_notes = (double *)ttb_notes,
    .p_durations = (uint16_t *)ttb_durations,
    .melody_length = BACKING_MELODY_LENGTH
};