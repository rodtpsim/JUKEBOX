/**
 * @file fsm_jukebox.h
 * @brief Header for fsm_jukebox.c file.
 * @remark This file is modified for V5
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gomez Fernandez-Getino
 * @date 05/2024
 */
#ifndef FSM_JUKEBOX_H_
#define FSM_JUKEBOX_H_

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <fsm.h>
#include "melodies.h"

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define MELODIES_MEMORY_SIZE 10 /*!< Number of melodies in the array melodies*/

/* Enums */
/**
 * @brief States of the FSM jukebox
 *
 */
enum FSM_JUKEBOX
{
    OFF = 0,         /*!< Starting and power off state */
    START_UP,        /*!< Intro melody and jukebox initialization*/
    WAIT_COMMAND,    /*!< Await for a command from the usart*/
    SLEEP_WHILE_OFF, /*!< Low power mode initialization when the jukebox is off*/
    SLEEP_WHILE_ON   /*!< Low power mode initialization when the jukebox is on*/
};

/* Typedefs ------------------------------------------------------------------*/
/**
 * @brief Jukebox FSM structure
 * 
 * @remark This function is modified for V5, adding the necessary pointers to the buzzer 2
 */
typedef struct
{
    fsm_t f;                                  /*!< Jukebox fsm*/
    melody_t melodies[MELODIES_MEMORY_SIZE];  /*!< Array of the names of the melodies played in buzzer 1*/
    melody_t melodies2[MELODIES_MEMORY_SIZE]; /*!< Array of the names of the melodies played in buzzer 2*/
    uint8_t melody_idx;                       /*!< Index of the melody played*/
    char *p_melody;                           /*!< Pointer to the name of the melody played in buzzer 1*/
    char *p_melody2;                          /*!< Pointer to the name of the melody played in buzzer 2*/
    fsm_t *p_fsm_button;                      /*!< Pointer to the button fsm*/
    uint32_t on_off_press_time_ms;            /*!< Time in ms to consider jukebox on or off*/
    fsm_t *p_fsm_usart;                       /*!< Pointer to the usart fsm */
    fsm_t *p_fsm_buzzer;                      /*!< Pointer to the buzzer 1 fsm */
    fsm_t *p_fsm_buzzer2;                     /*!< Pointer to the buzzer 2 fsm */
    uint32_t next_song_press_time_ms;         /*!< Time in ms to consider next song */
    double speed;                             /*!< Speed of the melody played */
} fsm_jukebox_t;

/* Function prototypes and explanation ---------------------------------------*/

/**
 * @brief Create a new jukebox fsm
 * 
 * @remark This function is modified for V5, adding the necessary pointers to the buzzer 2
 *
 * @param p_fsm_button pointer to the button fsm
 * @param on_off_press_time_ms press time in milliseconds of the button to turn the system ON or OFF
 * @param p_fsm_usart pointer to the usart fsm
 * @param p_fsm_buzzer pointer to the buzzer 1 fsm
 * @param p_fsm_buzzer2 pointer to the buzzer 2 fsm
 * @param next_song_press_time_ms press time in milliseconds of the button to change to the next song
 *
 * @return pointer to the button FSM
 */
fsm_t *fsm_jukebox_new(fsm_t *p_fsm_button, uint32_t on_off_press_time_ms, fsm_t *p_fsm_usart, fsm_t *p_fsm_buzzer, fsm_t *p_fsm_buzzer2, uint32_t next_song_press_time_ms);

/**
 * @brief Initialize a jukebox fsm
 * 
 * @remark This function is modified for V5, adding the necessary pointer to the buzzer 2 and the new melodies
 *
 * @param p_this pointer to a fsm struct
 * @param p_fsm_button pointer to the button fsm
 * @param on_off_press_time_ms press time in milliseconds of the button to turn the system ON or OFF
 * @param p_fsm_usart pointer to the usart fsm
 * @param p_fsm_buzzer pointer to the buzzer 1 fsm
 * @param p_fsm_buzzer2 pointer to the buzzer 2 fsm
 * @param next_song_press_time_ms press time in milliseconds of the button to change to the next song
 *
 */
void fsm_jukebox_init(fsm_t *p_this, fsm_t *p_fsm_button, uint32_t on_off_press_time_ms, fsm_t *p_fsm_usart, fsm_t *p_fsm_buzzer, fsm_t *p_fsm_buzzer2, uint32_t next_song_press_time_ms);

#endif /* FSM_JUKEBOX_H_ */