/**
 * @file fsm_button.h
 * @brief Header for fsm_button.c file.
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 02/2024
*/

#ifndef FSM_BUTTON_H_
#define FSM_BUTTON_H_

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include "fsm.h"

/* Defines and enums ----------------------------------------------------------*/
/* Enums */
/**
 * @brief States of the FSM button
 * 
 */
enum FSM_BUTTON
{
    BUTTON_RELEASED = 0,  /*!< Starting state. Also comes here when the button has been released*/
    BUTTON_RELEASED_WAIT, /*!< State to perform the anti-debounce mechanism for a falling edge*/
    BUTTON_PRESSED,       /*!< State while the button is being pressed*/
    BUTTON_PRESSED_WAIT,  /*!< State to perform the anti-debounce mechanism for a rising edge*/
};

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Button FSM structure
 */
typedef struct
{
    fsm_t f;                /*!< Button FSM */
    uint32_t debounce_time; /*!< Button debounce time in ms */
    uint32_t next_timeout;  /*!< Next timeout for the debounce in ms*/
    uint32_t tick_pressed;  /*!< Number of system ticks when the button was pressed */
    uint32_t duration;      /*!< How much time the button has been pressed */
    uint32_t button_id;     /*!< Unique button identifier number*/
} fsm_button_t;

/* Function prototypes and explanation -------------------------------------------------*/
/**
 * @brief Creates a new FSM for measuring how long the button is pressed
 *
 * @param debounce_time time (in ms) the FSM will wait in intermediate steps
 * @param button_id button identifier number
 *
 * @return fsm_t* pointer to the button FSM
 */
fsm_t *fsm_button_new(uint32_t debounce_time, uint32_t button_id);

/**
 * @brief Initializes all the parameters
 *
 * @param p_this pointer to the FSM
 * @param debounce_time time the FSM will wait in intermediate steps
 * @param button_id button identifier number
 */
void fsm_button_init(fsm_t *p_this, uint32_t debounce_time, uint32_t button_id);

/**
 * @brief Gets the latest duration measured by the button FSM
 *
 * @param p_this pointer to the button FSM
 *
 * @return uint32_t amount of time that the button has been pressed
 */
uint32_t fsm_button_get_duration(fsm_t *p_this);

/**
 * @brief Sets the duration measured by the button FSM to 0
 *
 * @param p_this pointer to the button FSM
 */
void fsm_button_reset_duration(fsm_t *p_this);

/**
 * @brief Checks if the button FSM is active or not
 *
 * @param p_this pointer to the button FSM
 *
 * @return boolean: true (active) or false (inactive)
 */
bool fsm_button_check_activity(fsm_t *p_this);

#endif /*FSM_BUTTON_H*/
