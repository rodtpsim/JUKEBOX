/**
 * @file fsm_buzzer2.h
 * @brief Header for fsm_buzzer2.c file.
 * @remark This file is created in V5
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 05/2024
 */

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include "fsm.h"
#include "melodies.h"

/* Defines and enums ----------------------------------------------------------*/
/* Enums */
/**
 * @brief States of the FSM buzzer 2
 * 
 */
enum FSM_BUZZER2 {
  WAIT_START2 = 0, /*!< Starting state or when a melody has been played */
  PLAY_NOTE2,      /*!< State to play a note */
  PAUSE_NOTE2,     /*!< State to pause the player */
  WAIT_NOTE2,      /*!< State to wait the the duration of the note played */
  WAIT_MELODY2     /*!< State to wait for a new melody*/
};
/**
 * @brief Actions of the FSM buzzer 2
 * 
 */
enum  
USER_ACTIONS2 {
  STOP2 = 0, /*!< Player stopped or requested a stop */
  PLAY2,     /*!< Player playing or requested playing*/
  PAUSE2     /*!< Player requested to stop */
};
 

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Buzzer 2 FSM structure
 */
typedef struct {
  fsm_t f2;             /*!< Buzzer FSM */
  melody_t *p_melody2;  /*!< Pointer to the melody to play */
  uint32_t note_index2; /*!< Index of the current note ready to play */
  uint8_t buzzer_id2;   /*!< Unique ID of the player buzzer */
  uint8_t user_action2; /*!< Action to perform on the player*/
  double player_speed2; /*!< Speed of the player */
} fsm_buzzer_t2;

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief Buzzer 2 FSM structure
 */
typedef struct
{
  fsm_t f;             /*!< Buzzer FSM */
  melody_t *p_melody;  /*!< Pointer to the melody to play */
  uint32_t note_index; /*!< Index of the current note ready to play */
  uint8_t buzzer_id;   /*!< Unique ID of the player buzzer */
  uint8_t user_action; /*!< Action to perform on the player*/
  double player_speed; /*!< Speed of the player */
} fsm_buzzer2_t;

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief Set the melody to be played
 *
 * @param p_this pointer to an fsm_t struct than contains an fsm_buzzer_t struct
 * @param p_melody pointer to the melody to play
 */
void fsm_buzzer_set_melody2(fsm_t *p_this, const melody_t *p_melody);

/**
 * @brief Set the speed of the player
 *
 * @param p_this pointer to an fsm_t struct than contains an fsm_buzzer_t struct
 * @param speed speed of the player
 *
 */
void fsm_buzzer_set_speed2(fsm_t *p_this, double speed);

/**
 * @brief Set the action to be done on the player
 *
 * @param p_this pointer to an fsm_t struct than contains an fsm_buzzer_t struct
 * @param action action to perform
 *
 */
void fsm_buzzer_set_action2(fsm_t *p_this, uint8_t action);

/**
 * @brief Get the action of the user
 *
 * @param p_this pointer to an fsm_t struct than contains an fsm_buzzer_t struct
 *
 * @return uint8_t action to perform on the player
 */
uint8_t fsm_buzzer_get_action2(fsm_t *p_this);

/**
 * @brief Creates a new buzzer
 *
 * @param buzzer_id unique buzzer identifier number
 *
 * @return pointer to the new buzzer finite state machine
 */
fsm_t *fsm_buzzer_new2(uint32_t buzzer_id);

/**
 * @brief Initialize a buzzer
 *
 * @param p_this pointer to an fsm_t struct than contains an fsm_buzzer_t struct
 * @param buzzer_id unique buzzer identifier number
 *
 */
void fsm_buzzer_init2(fsm_t *p_this, uint32_t buzzer_id);

/**
 * @brief Check if the buzzer machine is playing a melody
 *
 * @param p_this pointer to an fsm_t struct than contains an fsm_buzzer_t struct
 *
 * @return boolean: true (playing) or false (not playing)
 */
bool fsm_buzzer_check_activity2(fsm_t *p_this);