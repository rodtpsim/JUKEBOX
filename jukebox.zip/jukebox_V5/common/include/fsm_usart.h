/**
 * @file fsm_usart.h
 * @brief Header for fsm_usart.c file.
 * @author Rodrigo Tavares de Pina Simoes
 * @author Francisco Javier Gómez Fernández-Getino
 * @date 02/2024
 */

#ifndef FSM_USART_H_
#define FSM_USART_H_

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <fsm.h>
#include "port_usart.h"

/* Defines and enums ----------------------------------------------------------*/
/* Enums */
/**
 * @brief States of the FSM usart
 * 
 */
enum FSM_USART
{
    WAIT_DATA = 0, /*!< Starting state. Also comes here when the data has been sent or read*/
    SEND_DATA,     /*!< State to send data*/
};

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief USART FSM structure
 */
typedef struct
{
    fsm_t f;                                   /*!< USART FSM*/
    bool data_received;                        /*!< Flag to indicate that a data has been received*/
    char in_data[USART_INPUT_BUFFER_LENGTH];   /*!< Input data*/
    char out_data[USART_OUTPUT_BUFFER_LENGTH]; /*!< Output data*/
    uint32_t usart_id;                         /*!< USART ID. Must be unique*/
} fsm_usart_t;

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief Check if data has been received
 *
 * @param p_this pointer to fsm_t struct
 *
 * @return boolean: true (data received) or false (data not received)
 */
bool fsm_usart_check_data_received(fsm_t *p_this);

/**
 * @brief Disable the USART RX interrupt
 *
 * @param p_this pointer to fsm_t struct
 */
void fsm_usart_disable_rx_interrupt(fsm_t *p_this);

/**
 * @brief Disable the USART TX interrupt
 *
 * @param p_this pointer to fsm_t struct
 */
void fsm_usart_disable_tx_interrupt(fsm_t *p_this);

/**
 * @brief Enable the USART RX interrupt
 *
 * @param p_this pointer to fsm_t struct
 */
void fsm_usart_enable_rx_interrupt(fsm_t *p_this);

/**
 * @brief Enable the USART TX interrupt
 *
 * @param p_this pointer to fsm_t struct
 */
void fsm_usart_enable_tx_interrupt(fsm_t *p_this);

/**
 * @brief Get the data received
 *
 * @param p_this pointer to fsm_t struct
 * @param p_data pointer to array where the data will be copied
 */
void fsm_usart_get_in_data(fsm_t *p_this, char *p_data);

/**
 * @brief Initialize a USART FSM
 *
 * @param p_this pointer to fsm_t struct
 * @param usart_id USART identifier number
 */
void fsm_usart_init(fsm_t *p_this, uint32_t usart_id);

/**
 * @brief Create a new USART FSM
 *
 * @param usart_id USART identifier number
 *
 * @returns fsm_t* pointer to the USART FSM
 */
fsm_t *fsm_usart_new(uint32_t usart_id);

/**
 * @brief Reset the input data buffer
 *
 * @param p_this pointer to fsm_t struct
 */
void fsm_usart_reset_input_data(fsm_t *p_this);

/**
 * @brief Set the data to send
 *
 * @param p_this pointer to fsm_t struct
 * @param p_data pointer to array from where the data will be copied
 */
void fsm_usart_set_out_data(fsm_t *p_this, char *p_data);

/**
 * @brief Check if the USART FSM is active, or not
 *
 * @param p_this pointer to fsm_t struct
 *
 * @return boolean: true or false
 */
bool fsm_usart_check_activity(fsm_t *p_this);

#endif /* FSM_USART_H_ */