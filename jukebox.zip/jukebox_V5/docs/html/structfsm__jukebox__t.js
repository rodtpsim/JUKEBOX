var structfsm__jukebox__t =
[
    [ "f", "structfsm__jukebox__t.html#a445c7fa72d07ea41591a080bcacd292a", null ],
    [ "melodies", "structfsm__jukebox__t.html#af0acc2ecd1b669968ce5222d8319cf22", null ],
    [ "melodies2", "structfsm__jukebox__t.html#aaa6e3bdb0fa50ac5870e93d9fb1280ec", null ],
    [ "melody_idx", "structfsm__jukebox__t.html#aeae6a75054f62494284c7b54cf0cfb16", null ],
    [ "next_song_press_time_ms", "structfsm__jukebox__t.html#af6180677c01e68a5b3f04f46af026272", null ],
    [ "on_off_press_time_ms", "structfsm__jukebox__t.html#ad1f24b5cf4d01c29df9228a59bface9a", null ],
    [ "p_fsm_button", "structfsm__jukebox__t.html#a32809cca4f3b90688ef05007d0179798", null ],
    [ "p_fsm_buzzer", "structfsm__jukebox__t.html#a1dc18462fb596ae5325db1581a785976", null ],
    [ "p_fsm_buzzer2", "structfsm__jukebox__t.html#a4e7c5441788eb6918e5d3530a488cdec", null ],
    [ "p_fsm_usart", "structfsm__jukebox__t.html#a8ab49092e4f405f66586dd8b3bde5006", null ],
    [ "p_melody", "structfsm__jukebox__t.html#a7c2771c10c72039efa529f111a92bba7", null ],
    [ "p_melody2", "structfsm__jukebox__t.html#a95cfb16b2965554099e848bcfadeb524", null ],
    [ "speed", "structfsm__jukebox__t.html#aa092a915b9a4fdb5b1ab0003354f1032", null ]
];