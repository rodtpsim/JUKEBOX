var structport__usart__hw__t =
[
    [ "alt_func_rx", "structport__usart__hw__t.html#a51e60a515aa935a446ebcfc12f544a7f", null ],
    [ "alt_func_tx", "structport__usart__hw__t.html#af47e05873b634f4d92501613eadf1ca7", null ],
    [ "i_idx", "structport__usart__hw__t.html#aa67f870e47f9470737a4276b848f044a", null ],
    [ "input_buffer", "structport__usart__hw__t.html#a2c1a03f2d31ba67a741f726c688942c6", null ],
    [ "o_idx", "structport__usart__hw__t.html#afb69190eee2300893dd63745e8268afa", null ],
    [ "output_buffer", "structport__usart__hw__t.html#acd6d98b6d10b50616c785007c7bbe091", null ],
    [ "p_port_rx", "structport__usart__hw__t.html#a8d8332fd749328fef06d7c2fab911955", null ],
    [ "p_port_tx", "structport__usart__hw__t.html#a5e1dba640602b55ccedd775ffcefa131", null ],
    [ "p_usart", "structport__usart__hw__t.html#a3be856dfc59566c500b3ec341c90ba07", null ],
    [ "pin_rx", "structport__usart__hw__t.html#a63fdc08389c661e375ee327e60b32f3c", null ],
    [ "pin_tx", "structport__usart__hw__t.html#ac1b689aa54d6043eabc5048c29e70d09", null ],
    [ "read_complete", "structport__usart__hw__t.html#a309bdb856f90333eeb18a79ef2407988", null ],
    [ "write_complete", "structport__usart__hw__t.html#af74f21d818f0080800e89b1baa1b4823", null ]
];