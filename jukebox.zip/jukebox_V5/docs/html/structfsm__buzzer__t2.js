var structfsm__buzzer__t2 =
[
    [ "buzzer_id2", "structfsm__buzzer__t2.html#a25c7c74729f2a2edf50fa187a0ea328d", null ],
    [ "f2", "structfsm__buzzer__t2.html#a4bd3c95ce38e8353b98aa44c75ee80fa", null ],
    [ "note_index2", "structfsm__buzzer__t2.html#a9220b65264f8b8859c7b1cd5d9e029ca", null ],
    [ "p_melody2", "structfsm__buzzer__t2.html#aea11ab000a90ea9593358be3a7b0db33", null ],
    [ "player_speed2", "structfsm__buzzer__t2.html#a4b89c1bf50c865b4269b53bece89a9b8", null ],
    [ "user_action2", "structfsm__buzzer__t2.html#abde2dfa20b455fd4ecff441c2b31ad62", null ]
];