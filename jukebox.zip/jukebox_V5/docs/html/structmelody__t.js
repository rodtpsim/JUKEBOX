var structmelody__t =
[
    [ "melody_length", "structmelody__t.html#a99e199cd980a0f681f36be4e6a8e3410", null ],
    [ "p_durations", "structmelody__t.html#ae0cb1be6ac920f041a6becddd0ab20da", null ],
    [ "p_name", "structmelody__t.html#ac426bd3046fade4c5c3aa95c6c5a8124", null ],
    [ "p_notes", "structmelody__t.html#af76055d1552ab427c09fd3d397c4955c", null ]
];