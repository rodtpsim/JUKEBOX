var structport__button__hw__t =
[
    [ "flag_pressed", "structport__button__hw__t.html#ac294527bf82169781e405b4437d6a018", null ],
    [ "p_port", "structport__button__hw__t.html#a18802c2de0bafc6b825655eb60983152", null ],
    [ "pin", "structport__button__hw__t.html#a0edea41b6b5bfb8014d187e2df3d8f2f", null ]
];