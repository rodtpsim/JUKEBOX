var structport__buzzer__hw__t =
[
    [ "alt_func", "structport__buzzer__hw__t.html#a685b4e11cd1f54d32c25d7c66986e252", null ],
    [ "note_end", "structport__buzzer__hw__t.html#af7ad184d1c56c0fc736da4230ccb7b1d", null ],
    [ "p_port", "structport__buzzer__hw__t.html#aa1a68a90ce7fa77ce320142e701bb4ac", null ],
    [ "pin", "structport__buzzer__hw__t.html#ace70d3a5cc155dd74c20f5242d7e3d38", null ]
];