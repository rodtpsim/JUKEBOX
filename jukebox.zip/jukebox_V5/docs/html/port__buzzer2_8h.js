var port__buzzer2_8h =
[
    [ "port_buzzer_hw_t2", "structport__buzzer__hw__t2.html", "structport__buzzer__hw__t2" ],
    [ "BUZZER_1_AF", "port__buzzer2_8h.html#a146d85ffe3ff8459ade993576f087123", null ],
    [ "BUZZER_1_GPIO", "port__buzzer2_8h.html#a663add6a1c9f8807b8f6cd62889187be", null ],
    [ "BUZZER_1_ID", "port__buzzer2_8h.html#a3f7ab7c4f9fd5936fe5c96ed3cce3a4b", null ],
    [ "BUZZER_1_PIN", "port__buzzer2_8h.html#a69ddc012b1c7e52da64a9f300a3263bc", null ],
    [ "BUZZER_PWM_DC2", "port__buzzer2_8h.html#a18b64944f0e389a307b68d1329e03131", null ],
    [ "port_buzzer_get_note_timeout2", "port__buzzer2_8h.html#afe591c71354bcfc4bf4423ed42d6dda2", null ],
    [ "port_buzzer_init2", "port__buzzer2_8h.html#a6a59c373342a160ec43fb3c94d42da2b", null ],
    [ "port_buzzer_set_note_duration2", "port__buzzer2_8h.html#ad2f71a2fafd206dda01e80af074c7937", null ],
    [ "port_buzzer_set_note_frequency2", "port__buzzer2_8h.html#adefe6b7b1d00b8233856805e80d66a75", null ],
    [ "port_buzzer_stop2", "port__buzzer2_8h.html#a4743ba0c6600ea571e9d3268c2f69035", null ],
    [ "buzzers_arr2", "port__buzzer2_8h.html#a26406e0a35c74fff70c61fe3ffb0232f", null ]
];