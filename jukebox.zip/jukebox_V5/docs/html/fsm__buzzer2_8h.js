var fsm__buzzer2_8h =
[
    [ "fsm_buzzer_t2", "structfsm__buzzer__t2.html", "structfsm__buzzer__t2" ],
    [ "fsm_buzzer2_t", "structfsm__buzzer2__t.html", "structfsm__buzzer2__t" ],
    [ "FSM_BUZZER2", "fsm__buzzer2_8h.html#a47b1baaecb6ed65172fdc32782cfe853", [
      [ "WAIT_START2", "fsm__buzzer2_8h.html#a47b1baaecb6ed65172fdc32782cfe853a5a0d62e791ef5994770107e68674f03c", null ],
      [ "PLAY_NOTE2", "fsm__buzzer2_8h.html#a47b1baaecb6ed65172fdc32782cfe853a98518fcf15261a7dd0acb80807e1b8a2", null ],
      [ "PAUSE_NOTE2", "fsm__buzzer2_8h.html#a47b1baaecb6ed65172fdc32782cfe853a0599e8859b9fed76771408aab90cbb21", null ],
      [ "WAIT_NOTE2", "fsm__buzzer2_8h.html#a47b1baaecb6ed65172fdc32782cfe853a5c1885a7b24df5e719273dba974379ed", null ],
      [ "WAIT_MELODY2", "fsm__buzzer2_8h.html#a47b1baaecb6ed65172fdc32782cfe853a92a452d5adf663ef78bad909b5e931c7", null ]
    ] ],
    [ "USER_ACTIONS2", "fsm__buzzer2_8h.html#a3a561844773c02c7e592e6fb5ffcaa82", [
      [ "STOP2", "fsm__buzzer2_8h.html#a3a561844773c02c7e592e6fb5ffcaa82addc213ae1bf6c9c3501c96c1da4e8c51", null ],
      [ "PLAY2", "fsm__buzzer2_8h.html#a3a561844773c02c7e592e6fb5ffcaa82afbd29c716335be49c2e4fa31c630f069", null ],
      [ "PAUSE2", "fsm__buzzer2_8h.html#a3a561844773c02c7e592e6fb5ffcaa82a441acfc85a00d87387260aff1fe8f6a1", null ]
    ] ],
    [ "fsm_buzzer_check_activity2", "fsm__buzzer2_8h.html#a7730368faa8b29ce511a8db2aa0011fe", null ],
    [ "fsm_buzzer_get_action2", "fsm__buzzer2_8h.html#ac462b41e72ac65c6533da66a58146375", null ],
    [ "fsm_buzzer_init2", "fsm__buzzer2_8h.html#a130ba3633ac6af73693da48547a79d12", null ],
    [ "fsm_buzzer_new2", "fsm__buzzer2_8h.html#aacfc407d2292852592c11e6d4dd46d08", null ],
    [ "fsm_buzzer_set_action2", "fsm__buzzer2_8h.html#a45771c96b19eb2d3167fd82d04a63ed8", null ],
    [ "fsm_buzzer_set_melody2", "fsm__buzzer2_8h.html#af62a4336929dd26dd23ebf2c3af6da0f", null ],
    [ "fsm_buzzer_set_speed2", "fsm__buzzer2_8h.html#a4479635bb61868162617256351ed08b5", null ]
];