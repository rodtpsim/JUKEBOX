var structfsm__buzzer2__t =
[
    [ "buzzer_id", "structfsm__buzzer2__t.html#a5c2dba7dd067acdd136080ec28ece9f3", null ],
    [ "f", "structfsm__buzzer2__t.html#a86eddfd522e9308356d1eb37d30c7908", null ],
    [ "note_index", "structfsm__buzzer2__t.html#a0d9520f9aa2fbf0650491d7f4c4e276d", null ],
    [ "p_melody", "structfsm__buzzer2__t.html#a8dd01f633cfd1a48007901535064c880", null ],
    [ "player_speed", "structfsm__buzzer2__t.html#a64383edee03f90b044c27ac63c6ff65d", null ],
    [ "user_action", "structfsm__buzzer2__t.html#aba717331f3eddbbf0a09269246c23d25", null ]
];