var structfsm__buzzer__t =
[
    [ "buzzer_id", "structfsm__buzzer__t.html#a6d7510e2520ba91cf0b6b669dd5e8240", null ],
    [ "f", "structfsm__buzzer__t.html#a3c703abfd764a869295e1457cc7302ca", null ],
    [ "note_index", "structfsm__buzzer__t.html#a23d8938be6a7f52140106408258dc893", null ],
    [ "p_melody", "structfsm__buzzer__t.html#a0f6b49bb5a98a346cde75c57771b3120", null ],
    [ "player_speed", "structfsm__buzzer__t.html#a4c1551e40b0a2a0ffea8e3716cec735c", null ],
    [ "user_action", "structfsm__buzzer__t.html#af0888a6737f7823ecc75ad22a390a694", null ]
];