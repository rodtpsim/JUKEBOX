var searchData=
[
  ['power_5fregulator_5fvoltage_5fscale3_0',['POWER_REGULATOR_VOLTAGE_SCALE3',['../port__system_8h.html#aba9b17980f912ee6faefbf82071fdeae',1,'port_system.h']]]
];
