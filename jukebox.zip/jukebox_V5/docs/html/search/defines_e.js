var searchData=
[
  ['tetris_5flength_0',['TETRIS_LENGTH',['../melodies_8c.html#a064fa8d897b24fde3879d5f50ccbb4f6',1,'melodies.c']]],
  ['tick_5ffreq_5f1khz_1',['TICK_FREQ_1KHZ',['../port__system_8h.html#aafb4caba8017f1b553bd78f60ecd11c4',1,'port_system.h']]],
  ['trigger_5fboth_5fedge_2',['TRIGGER_BOTH_EDGE',['../port__system_8h.html#a5ce133b438a7f41ce84fed71ea845994',1,'port_system.h']]],
  ['trigger_5fenable_5fevent_5freq_3',['TRIGGER_ENABLE_EVENT_REQ',['../port__system_8h.html#ae61a653b05cde66da4d063eac13caf54',1,'port_system.h']]],
  ['trigger_5fenable_5finterr_5freq_4',['TRIGGER_ENABLE_INTERR_REQ',['../port__system_8h.html#a913206b89f97752e3fac1ba0b2320aa5',1,'port_system.h']]],
  ['trigger_5ffalling_5fedge_5',['TRIGGER_FALLING_EDGE',['../port__system_8h.html#a1968e3b27d1799d15d4183db2267d4c4',1,'port_system.h']]],
  ['trigger_5frising_5fedge_6',['TRIGGER_RISING_EDGE',['../port__system_8h.html#ab1f803abb36eac6342cad8854fbc1e10',1,'port_system.h']]],
  ['twinkle_5fmelody_5flength_7',['TWINKLE_MELODY_LENGTH',['../melodies_8c.html#a7162ae6802d7c06af8cbeecf95322ae4',1,'melodies.c']]]
];
