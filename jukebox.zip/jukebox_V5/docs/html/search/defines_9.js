var searchData=
[
  ['next_5fsong_5fbutton_5ftime_5fms_0',['NEXT_SONG_BUTTON_TIME_MS',['../main_8c.html#ac680b2a7759fb431b20be1f3e28330f9',1,'main.c']]],
  ['nvic_5fpriority_5fgroup_5f0_1',['NVIC_PRIORITY_GROUP_0',['../port__system_8h.html#a63af9a501c857ba12e0e977df6e38fb6',1,'port_system.h']]],
  ['nvic_5fpriority_5fgroup_5f4_2',['NVIC_PRIORITY_GROUP_4',['../port__system_8h.html#a5b7ebf3d3bc5d33a6cd8b3fb3903cf4f',1,'port_system.h']]]
];
