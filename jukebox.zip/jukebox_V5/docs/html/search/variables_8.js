var searchData=
[
  ['o_5fidx_0',['o_idx',['../structport__usart__hw__t.html#afb69190eee2300893dd63745e8268afa',1,'port_usart_hw_t']]],
  ['on_5foff_5fpress_5ftime_5fms_1',['on_off_press_time_ms',['../structfsm__jukebox__t.html#ad1f24b5cf4d01c29df9228a59bface9a',1,'fsm_jukebox_t']]],
  ['out_5fdata_2',['out_data',['../structfsm__usart__t.html#aa1b21fb8758d9c6357e313cac9d98f04',1,'fsm_usart_t']]],
  ['output_5fbuffer_3',['output_buffer',['../structport__usart__hw__t.html#acd6d98b6d10b50616c785007c7bbe091',1,'port_usart_hw_t']]]
];
