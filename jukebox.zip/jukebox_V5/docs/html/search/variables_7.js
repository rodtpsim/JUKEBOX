var searchData=
[
  ['next_5fsong_5fpress_5ftime_5fms_0',['next_song_press_time_ms',['../structfsm__jukebox__t.html#af6180677c01e68a5b3f04f46af026272',1,'fsm_jukebox_t']]],
  ['next_5ftimeout_1',['next_timeout',['../structfsm__button__t.html#a2cb938cc094cc3668b120954f69dcaab',1,'fsm_button_t']]],
  ['note_5fend_2',['note_end',['../structport__buzzer__hw__t.html#af7ad184d1c56c0fc736da4230ccb7b1d',1,'port_buzzer_hw_t']]],
  ['note_5fend2_3',['note_end2',['../structport__buzzer__hw__t2.html#a89cb1152586b5b64cf7010399d6a99ab',1,'port_buzzer_hw_t2']]],
  ['note_5findex_4',['note_index',['../structfsm__buzzer__t.html#a23d8938be6a7f52140106408258dc893',1,'fsm_buzzer_t::note_index'],['../structfsm__buzzer2__t.html#a0d9520f9aa2fbf0650491d7f4c4e276d',1,'fsm_buzzer2_t::note_index']]],
  ['note_5findex2_5',['note_index2',['../structfsm__buzzer__t2.html#a9220b65264f8b8859c7b1cd5d9e029ca',1,'fsm_buzzer_t2']]]
];
