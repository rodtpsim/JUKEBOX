var searchData=
[
  ['data_5freceived_0',['data_received',['../structfsm__usart__t.html#a49db4011651ca1e502ba6c45318de688',1,'fsm_usart_t']]],
  ['debounce_5ftime_1',['debounce_time',['../structfsm__button__t.html#a6c0ec19d949ded12e7e717480e9f4b95',1,'fsm_button_t']]],
  ['duration_2',['duration',['../structfsm__button__t.html#a1e5344fc8cb65595a3723a3e85d12618',1,'fsm_button_t']]]
];
