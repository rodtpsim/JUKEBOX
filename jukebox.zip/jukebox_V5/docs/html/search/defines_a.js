var searchData=
[
  ['on_5foff_5fpress_5ftime_5fms_0',['ON_OFF_PRESS_TIME_MS',['../main_8c.html#a52976ddc156b87a984ce88a78c689176',1,'main.c']]]
];
