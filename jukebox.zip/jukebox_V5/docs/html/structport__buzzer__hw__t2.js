var structport__buzzer__hw__t2 =
[
    [ "alt_func2", "structport__buzzer__hw__t2.html#a61a97a650a9a31243cb713454574bc2d", null ],
    [ "note_end2", "structport__buzzer__hw__t2.html#a89cb1152586b5b64cf7010399d6a99ab", null ],
    [ "p_port2", "structport__buzzer__hw__t2.html#afff91a60498f07199a0508919db8728c", null ],
    [ "pin2", "structport__buzzer__hw__t2.html#af2e9b99a93fde7cc5716847cac5d8980", null ]
];