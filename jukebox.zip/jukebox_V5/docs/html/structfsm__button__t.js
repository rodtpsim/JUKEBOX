var structfsm__button__t =
[
    [ "button_id", "structfsm__button__t.html#a118e470443c45dd1602201b89b8d4a2a", null ],
    [ "debounce_time", "structfsm__button__t.html#a6c0ec19d949ded12e7e717480e9f4b95", null ],
    [ "duration", "structfsm__button__t.html#a1e5344fc8cb65595a3723a3e85d12618", null ],
    [ "f", "structfsm__button__t.html#aa0240ddd45d2861c0aaf0e0a4df3bb7e", null ],
    [ "next_timeout", "structfsm__button__t.html#a2cb938cc094cc3668b120954f69dcaab", null ],
    [ "tick_pressed", "structfsm__button__t.html#aafa5c3aa3c9af09aa7d0c8e32db6102f", null ]
];