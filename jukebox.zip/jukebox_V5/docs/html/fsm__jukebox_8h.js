var fsm__jukebox_8h =
[
    [ "fsm_jukebox_t", "structfsm__jukebox__t.html", "structfsm__jukebox__t" ],
    [ "MELODIES_MEMORY_SIZE", "fsm__jukebox_8h.html#a67e2267d6018c4111c6e24c60fe97508", null ],
    [ "FSM_JUKEBOX", "fsm__jukebox_8h.html#abdf54306266ae93f1f99b64ff95e4c8f", [
      [ "OFF", "fsm__jukebox_8h.html#abdf54306266ae93f1f99b64ff95e4c8faac132f2982b98bcaa3445e535a03ff75", null ],
      [ "START_UP", "fsm__jukebox_8h.html#abdf54306266ae93f1f99b64ff95e4c8fa9900c1254634ce4f5fb551e90e15fbaa", null ],
      [ "WAIT_COMMAND", "fsm__jukebox_8h.html#abdf54306266ae93f1f99b64ff95e4c8fad7d715a85860f95a6bc552d7bd02dcd5", null ],
      [ "SLEEP_WHILE_OFF", "fsm__jukebox_8h.html#abdf54306266ae93f1f99b64ff95e4c8fa30dd63ccd40677f8b3eb01f8ad352ce7", null ],
      [ "SLEEP_WHILE_ON", "fsm__jukebox_8h.html#abdf54306266ae93f1f99b64ff95e4c8facfc8a9bfe175888d8890411703c267f4", null ]
    ] ],
    [ "fsm_jukebox_init", "fsm__jukebox_8h.html#a0c8458022f7092d39b0e4a91e60d295c", null ],
    [ "fsm_jukebox_new", "fsm__jukebox_8h.html#a158b6f9ae9fe6e406342e6da85e7b568", null ]
];