var main_8c =
[
    [ "NEXT_SONG_BUTTON_TIME_MS", "main_8c.html#ac680b2a7759fb431b20be1f3e28330f9", null ],
    [ "ON_OFF_PRESS_TIME_MS", "main_8c.html#a52976ddc156b87a984ce88a78c689176", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];