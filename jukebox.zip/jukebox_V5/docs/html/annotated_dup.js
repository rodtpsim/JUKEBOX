var annotated_dup =
[
    [ "fsm_button_t", "structfsm__button__t.html", "structfsm__button__t" ],
    [ "fsm_buzzer2_t", "structfsm__buzzer2__t.html", "structfsm__buzzer2__t" ],
    [ "fsm_buzzer_t", "structfsm__buzzer__t.html", "structfsm__buzzer__t" ],
    [ "fsm_buzzer_t2", "structfsm__buzzer__t2.html", "structfsm__buzzer__t2" ],
    [ "fsm_jukebox_t", "structfsm__jukebox__t.html", "structfsm__jukebox__t" ],
    [ "fsm_usart_t", "structfsm__usart__t.html", "structfsm__usart__t" ],
    [ "melody_t", "structmelody__t.html", "structmelody__t" ],
    [ "port_button_hw_t", "structport__button__hw__t.html", "structport__button__hw__t" ],
    [ "port_buzzer_hw_t", "structport__buzzer__hw__t.html", "structport__buzzer__hw__t" ],
    [ "port_buzzer_hw_t2", "structport__buzzer__hw__t2.html", "structport__buzzer__hw__t2" ],
    [ "port_usart_hw_t", "structport__usart__hw__t.html", "structport__usart__hw__t" ]
];